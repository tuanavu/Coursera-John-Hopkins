Regression-Models
=================

For the Coursera course of the Johns Hopkins Data Science specialization
