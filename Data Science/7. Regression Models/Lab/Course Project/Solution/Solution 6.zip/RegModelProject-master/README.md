#### Convert RMarkdown to pdf file

Used Latest version of R studio and Install MiKTex 2.9 and Pandoc

Generate knit PDF from Rstudio by running Rmd file.



