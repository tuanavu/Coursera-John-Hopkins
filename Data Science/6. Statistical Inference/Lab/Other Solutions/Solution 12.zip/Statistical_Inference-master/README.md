Statistical_Inference
=====================

repo for the Statistical Inference course offered through Coursera
