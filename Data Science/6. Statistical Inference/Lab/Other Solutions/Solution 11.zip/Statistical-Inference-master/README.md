Statistical-Inference
=====================

Coursera course on statistical inference
