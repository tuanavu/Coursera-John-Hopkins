Statistical_Inference
=====================

Statistical Inference online class from Coursera

Two .Rmd files to produce PDFs for the class project


