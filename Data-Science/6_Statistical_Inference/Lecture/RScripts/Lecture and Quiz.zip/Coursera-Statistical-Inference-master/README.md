Coursera-Statistical-Inference
==============================
Programming Assignments of Coursera.com online course: Statistical Inference

This is a four-week course. Jul 7th - Aug 4th, 2014.

© Xiaodan Zhang 2014 All Rights reserved.
