coursera_DSS_regression_models
==============================

The aim is to explore the relationship between a set of variables and miles per gallon (MPG) as the outcome of interest. The data was extracted from the 1974 Motor Trend US magazine, and comprises fuel consumption and 10 aspects of automobile design and performance for 32 automobiles (1973-74 models). Dataset: Motor Trend Car Road Tests  <https://stat.ethz.ch/R-manual/R-devel/library/datasets/html/mtcars.html>. 

.
