RegModel
========

Coursera Regression Models course project
